package com.yonggang.liyangyang.iyonggang;

/**
 * Created by liyangyang on 2017/6/12.
 */

public class Domain {
    public static final String URL = "http://192.168.0.224:82";
}

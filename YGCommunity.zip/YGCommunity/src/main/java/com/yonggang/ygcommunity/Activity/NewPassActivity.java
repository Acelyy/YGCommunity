package com.yonggang.ygcommunity.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.yonggang.ygcommunity.BaseActivity;
import com.yonggang.ygcommunity.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class NewPassActivity extends BaseActivity {

    @BindView(R.id.edit_pass)
    EditText editPass;
    @BindView(R.id.edit_identify)
    EditText editIdentify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_pass);
        ButterKnife.bind(this);
    }

    @OnClick({R.id.img_finish, R.id.btn_next})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.img_finish:
                break;
            case R.id.btn_next:
                break;
        }
    }
}

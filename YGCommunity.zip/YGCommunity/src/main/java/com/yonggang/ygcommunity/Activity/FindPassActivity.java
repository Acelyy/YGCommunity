package com.yonggang.ygcommunity.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.yonggang.ygcommunity.BaseActivity;
import com.yonggang.ygcommunity.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class FindPassActivity extends BaseActivity {

    @BindView(R.id.edit_tel)
    EditText editTel;
    @BindView(R.id.edit_identify)
    EditText editIdentify;
    @BindView(R.id.forget_send_identify)
    TextView forgetSendIdentify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_pass);
        ButterKnife.bind(this);
    }

    @OnClick({R.id.img_finish, R.id.forget_send_identify, R.id.btn_next})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.img_finish:
                finish();
                break;
            case R.id.forget_send_identify:
                break;
            case R.id.btn_next:
                break;
        }
    }
}

package com.yonggang.ygcommunity.View;

import android.content.Context;
import android.os.Handler;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.yonggang.ygcommunity.R;

import java.util.ArrayList;

/**
 * Created by liyangyang on 2017/2/27.
 */

public class ImageCycleView extends LinearLayout {
    private Context mContext;

    private ViewPager mAdvPager = null;

    private ImageCycleAdapter mAdvAdapter;

    private ViewGroup mGroup;

    private ImageView mImageView = null;

    private ImageView[] mImageViews = null;

    private int mImageIndex = 0;

    private float mScale;

    public ImageCycleView(Context context) {
        super(context);
    }

    /**
     * @param context
     * @param attrs
     */
    public ImageCycleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        View rl = LayoutInflater.from(context).inflate(R.layout.ad_cycle_view,
                this);
        mAdvPager = (ViewPager) rl.findViewById(R.id.adv_pager);
        mAdvPager.setOnPageChangeListener(new GuidePageChangeListener());
        mAdvPager.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        // 手指抬起是继续开启自动播放
                        startImageTimerTask();
                        break;
                    default:
                        // 除了手指抬起，不管滑动还是按下，都停止播放
                        stopImageTimerTask();
                        break;
                }
                return false;
            }
        });
        // 用来存放下面那个点
        mGroup = (ViewGroup) rl.findViewById(R.id.viewGroup);
    }

    /**
     * @param imageUrlList
     * @param imageCycleViewListener
     */
    public void setImageResources(ArrayList<Integer> imageUrlList,
                                  ImageCycleViewListener imageCycleViewListener, boolean has_points) {
        if (!has_points) {
            mGroup.setVisibility(View.VISIBLE);
        }
        mGroup.removeAllViews();
        final int imageCount = imageUrlList.size();
        mImageViews = new ImageView[imageCount];
        for (int i = 0; i < imageCount; i++) {
            mImageView = new ImageView(mContext);
            mImageView.setLayoutParams(new LayoutParams(32, 20));
            mImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            mImageViews[i] = mImageView;
            //设置图片下面的点，可以根据不同的需求，改成不同的图片资源
            if (i == 0) {
                //选中时的点
                mImageViews[i].setBackgroundResource(R.mipmap.dot2_w);
            } else {
                //未选中时的点
                mImageViews[i].setBackgroundResource(R.mipmap.dot1_w);
            }
            mGroup.addView(mImageViews[i]);
        }
        mAdvAdapter = new ImageCycleAdapter(mContext, imageUrlList,
                imageCycleViewListener);
        mAdvPager.setAdapter(mAdvAdapter);
        startImageTimerTask();
    }

    /**
     * 设置是否显示底下原点
     *
     * @param visible
     */
    public void setPointVisible(boolean visible) {
        if (visible) {
            mGroup.setVisibility(View.VISIBLE);
        } else {
            mGroup.setVisibility(View.INVISIBLE);
        }
    }

    /**
     * 开启播放，用于类以外调用
     */
    public void startImageCycle() {
        startImageTimerTask();
    }

    /**
     * 停止播放，用于类以外调用
     */
    public void pushImageCycle() {
        stopImageTimerTask();
    }

    /**
     * 开启播放，本类内部调用
     */
    private void startImageTimerTask() {
        stopImageTimerTask();
        // 播放的时间间隔
        mHandler.postDelayed(mImageTimerTask, 3000);
    }

    /**
     * 停止播放，本类内部调用
     */
    private void stopImageTimerTask() {
        mHandler.removeCallbacks(mImageTimerTask);
    }

    private Handler mHandler = new Handler();

    /**
     * 播放线程
     */
    private Runnable mImageTimerTask = new Runnable() {

        @Override
        public void run() {
            if (mImageViews != null) {
                // 轮播
                if ((++mImageIndex) == mImageViews.length) {
                    mImageIndex = 0;
                }
                // Toast.makeText(mContext, mImageIndex+"", 0).show();
                mAdvPager.setCurrentItem(mImageIndex);
            }
        }
    };

    private final class GuidePageChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageScrollStateChanged(int state) {
            if (state == ViewPager.SCROLL_STATE_IDLE)
                startImageTimerTask();
        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        @Override
        public void onPageSelected(int index) {
            mImageIndex = index;
            mImageViews[index].setBackgroundResource(R.mipmap.dot2_w);
            for (int i = 0; i < mImageViews.length; i++) {
                if (index != i) {
                    mImageViews[i].setBackgroundResource(R.mipmap.dot1_w);
                }
            }

        }

    }

    private class ImageCycleAdapter extends PagerAdapter {

        private ArrayList<ImageView> mImageViewCacheList;

        private ArrayList<Integer> mAdList = new ArrayList<Integer>();

        private ImageCycleViewListener mImageCycleViewListener;

        private Context mContext;

        public ImageCycleAdapter(Context context, ArrayList<Integer> adList,
                                 ImageCycleViewListener imageCycleViewListener) {
            mContext = context;
            mAdList = adList;
            mImageCycleViewListener = imageCycleViewListener;
            mImageViewCacheList = new ArrayList<ImageView>();
        }

        @Override
        public int getCount() {
            return mAdList.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object obj) {
            return view == obj;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            final int index = position;
            int imageUrl = mAdList.get(position);
            ImageView imageView = null;
            if (mImageViewCacheList.isEmpty()) {
                imageView = new ImageView(mContext);
                imageView.setLayoutParams(new LayoutParams(
                        LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
                imageView.setScaleType(ImageView.ScaleType.FIT_XY);
                imageView.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mImageCycleViewListener.onImageClick(index, v);
                    }
                });
            } else {
                imageView = mImageViewCacheList.remove(0);
            }
            imageView.setTag(imageUrl);
            container.addView(imageView);
            mImageCycleViewListener.displayImage(imageUrl, imageView);
            return imageView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            ImageView view = (ImageView) object;
            container.removeView(view);
            mImageViewCacheList.add(view);
        }

    }

    /**
     *
     */
    public static interface ImageCycleViewListener {

        /**
         * 设置图片资源，这里默认的是加载本地图片，如果需要设置网络图片资源，可以将int类型改为String
         *
         * @param imageURL
         * @param imageView
         */
        public void displayImage(int imageURL, ImageView imageView);

        /**
         * 点击事件，position
         *
         * @param position
         * @param imageView
         */
        public void onImageClick(int position, View imageView);
    }

    /**
     * 不知道为什么onImageClick(int position, View
     * imageView)的position会乱，加了个getIndex来代替position
     */
    public int getIndex() {
        return mImageIndex;
    }
}

package com.yonggang.ygcommunity.Fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.yonggang.ygcommunity.R;

import butterknife.ButterKnife;

/**
 * Created by liyangyang on 2017/2/25.
 */

public class AssemblyFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.layout_fragment_assembly, container, false);
        ButterKnife.bind(this, view);
        return view;
    }
}

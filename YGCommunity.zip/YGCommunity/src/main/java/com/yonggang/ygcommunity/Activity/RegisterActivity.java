package com.yonggang.ygcommunity.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.yonggang.ygcommunity.BaseActivity;
import com.yonggang.ygcommunity.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class RegisterActivity extends BaseActivity {

    @BindView(R.id.edit_tel)
    EditText editTel;
    @BindView(R.id.edit_identify)
    EditText editIdentify;
    @BindView(R.id.register_send_identify)
    TextView registerSendIdentify;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);
    }

    @OnClick({R.id.img_finish, R.id.btn_next, R.id.register_send_identify})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.img_finish:
                finish();
                break;
            case R.id.btn_next:
                goActivity(SetPassActivity.class);
                break;
            case R.id.register_send_identify:
                break;
        }
    }
}

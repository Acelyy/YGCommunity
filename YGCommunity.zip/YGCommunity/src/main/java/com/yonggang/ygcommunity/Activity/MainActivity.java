package com.yonggang.ygcommunity.Activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.yonggang.ygcommunity.Fragment.AssemblyFragment;
import com.yonggang.ygcommunity.Fragment.MainFragment;
import com.yonggang.ygcommunity.Fragment.MineFragment;
import com.yonggang.ygcommunity.Fragment.ServerFragment;
import com.yonggang.ygcommunity.R;

import java.util.List;

import butterknife.BindColor;
import butterknife.BindViews;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends FragmentActivity {
    @BindViews({R.id.pic_main, R.id.pic_server, R.id.pic_assembly, R.id.pic_mime})
    public List<ImageView> buttons;

    @BindViews({R.id.text_main, R.id.text_server, R.id.text_assembly, R.id.text_mine})
    public List<TextView> textViews;

    @BindColor(R.color.colorMainClick)
    public int colorMainClick;
    @BindColor(R.color.colorMainUnclick)
    public int colorMainUnclick;

    private Fragment[] fragments;

    private int currentItem = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        fragments = new Fragment[]{new MainFragment(), new ServerFragment(), new AssemblyFragment(), new MineFragment()};
        getSupportFragmentManager().beginTransaction()
                .add(R.id.main_content, fragments[0])
                .add(R.id.main_content, fragments[1])
                .add(R.id.main_content, fragments[2])
                .add(R.id.main_content, fragments[3])
                .hide(fragments[1]).hide(fragments[2])
                .hide(fragments[3])
                .show(fragments[0])
                .commit();
        buttons.get(0).setSelected(true);
        textViews.get(0).setTextColor(colorMainClick);
    }

    /**
     * 切换Fragment的方法
     *
     * @param index 页码
     */
    private void changeFragment(int index) {
        if (currentItem != index) {
            FragmentTransaction trx = getSupportFragmentManager().beginTransaction();
            trx.hide(fragments[currentItem]);
            if (!fragments[index].isAdded()) {
                trx.add(R.id.main_content, fragments[index]);
            }
            trx.show(fragments[index]).commit();
        }
        buttons.get(currentItem).setSelected(false);
        buttons.get(index).setSelected(true);

        textViews.get(currentItem).setTextColor(colorMainUnclick);
        textViews.get(index).setTextColor(colorMainClick);
        currentItem = index;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(true);
        }
        return super.onKeyDown(keyCode, event);
    }

    @OnClick({R.id.layout_main, R.id.layout_server, R.id.layout_assembly, R.id.layout_mine})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.layout_main:
                changeFragment(0);
                break;
            case R.id.layout_server:
                changeFragment(1);
                break;
            case R.id.layout_assembly:
                changeFragment(2);
                break;
            case R.id.layout_mine:
                changeFragment(3);
                break;
        }
    }
}

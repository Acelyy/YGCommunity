package com.yonggang.ygcommunity.Fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.yonggang.ygcommunity.Fragment.Server.ActivityFragment;
import com.yonggang.ygcommunity.Fragment.Server.ElectricFragment;
import com.yonggang.ygcommunity.Fragment.Server.SearchFragment;
import com.yonggang.ygcommunity.Fragment.Server.TelFragment;
import com.yonggang.ygcommunity.Fragment.Server.WaterFragment;
import com.yonggang.ygcommunity.R;
import com.yonggang.ygcommunity.View.ImageCycleView;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.BindViews;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by liyangyang on 2017/2/25.
 */

public class ServerFragment extends Fragment {
    @BindView(R.id.server_banner)
    public ImageCycleView assembly_banner;

    @BindViews({R.id.line_search, R.id.line_tel, R.id.line_activity, R.id.line_water, R.id.line_electric})
    LinearLayout[] lineList;

    @BindView(R.id.pager)
    ViewPager pager;

    @OnClick({R.id.tab_search, R.id.tab_tel, R.id.tab_activity, R.id.tab_water, R.id.tab_electric})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tab_search:
                index = 0;
                break;
            case R.id.tab_tel:
                index = 1;
                break;
            case R.id.tab_activity:
                index = 2;
                break;
            case R.id.tab_water:
                index = 3;
                break;
            case R.id.tab_electric:
                index = 4;
                break;

        }
        if (currentItem != index) {
            pager.setCurrentItem(index, false);
            imageMove(index);
        }
    }

    /**
     * 存储轮播图的列表
     */
    private ArrayList<Integer> mImageUrl = new ArrayList<Integer>();

    /**
     * 储存Fragments的数据
     */
    private Fragment[] fragments;

    /**
     * 切换到的item
     */
    private int index;

    /**
     * 切换前的item
     */
    private int currentItem;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.layout_fragment_server, container, false);
        ButterKnife.bind(this, view);
        //添加测试数据
        mImageUrl.add(R.mipmap.assembly_test1);
        mImageUrl.add(R.mipmap.assembly_test2);
        mImageUrl.add(R.mipmap.assembly_test3);
        mImageUrl.add(R.mipmap.assembly_test4);
        assembly_banner.setImageResources(mImageUrl, mAdCycleViewListener, true);
        fragments = new Fragment[]{new SearchFragment(), new TelFragment(), new ActivityFragment(), new WaterFragment(), new ElectricFragment()};
        pager.setAdapter(new MyFragmentStatePagerAdapter(getChildFragmentManager()));
        imageMove(index);
        return view;
    }

    /**
     * 轮播图的监听
     */
    private ImageCycleView.ImageCycleViewListener mAdCycleViewListener = new ImageCycleView.ImageCycleViewListener() {
        @Override
        public void displayImage(int imageURL, ImageView imageView) {
            imageView.setImageResource(imageURL);
        }

        @Override
        public void onImageClick(int position, View imageView) {

        }
    };


    /**
     * 定义自己的ViewPager适配器。 也可以使用FragmentPagerAdapter。
     */
    class MyFragmentStatePagerAdapter extends FragmentStatePagerAdapter {

        public MyFragmentStatePagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            return fragments[position];
        }

        @Override
        public int getCount() {
            return fragments.length;
        }

        /**
         * 每次更新完成ViewPager的内容后，调用该接口，此处复写主要是为了让导航按钮上层的覆盖层能够动态的移动
         */
        @Override
        public void finishUpdate(ViewGroup container) {
            super.finishUpdate(container);
            // 获取当前的视图是位于ViewGroup的第几个位置，用来更新对应的覆盖层所在的位置
            int currentItem = pager.getCurrentItem();
            if (currentItem == index) {
                return;
            }
            imageMove(pager.getCurrentItem());
        }

    }

    /**
     * 切换Fragment后的界面更新
     *
     * @param index
     */
    private void imageMove(int index) {
        lineList[currentItem].setSelected(false);
        lineList[index].setSelected(true);
        currentItem = index;
    }
}

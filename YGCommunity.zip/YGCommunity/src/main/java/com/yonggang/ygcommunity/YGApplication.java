package com.yonggang.ygcommunity;

import android.app.Application;

import cn.jpush.android.api.JPushInterface;

/**
 * Created by liyangyang on 2017/2/13.
 */

public class YGApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        JPushInterface.setDebugMode(true);
        JPushInterface.init(this);
    }
}

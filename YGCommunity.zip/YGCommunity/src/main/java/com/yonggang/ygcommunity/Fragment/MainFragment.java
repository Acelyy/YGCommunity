package com.yonggang.ygcommunity.Fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.yonggang.ygcommunity.Fragment.Main.NewsFragment;
import com.yonggang.ygcommunity.R;
import com.yonggang.ygcommunity.View.PagerSlidingTabStrip;

import butterknife.BindView;
import butterknife.ButterKnife;


/**
 * Created by liyangyang on 2017/2/25.
 */

public class MainFragment extends Fragment {

    @BindView(R.id.tabs)
    PagerSlidingTabStrip tabs;
    @BindView(R.id.pager)
    ViewPager pager;

    Fragment[] news;

    MyPagerAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.layout_fragment_main, container, false);
        ButterKnife.bind(this, view);
        news = new Fragment[]{new NewsFragment(), new NewsFragment(), new NewsFragment(), new NewsFragment(), new NewsFragment(), new NewsFragment(), new NewsFragment()};
        adapter = new MyPagerAdapter(getChildFragmentManager());

        pager.setAdapter(adapter);
        tabs.setViewPager(pager);
        return view;
    }

    public class MyPagerAdapter extends FragmentPagerAdapter {

        private final String[] TITLES = {"要闻", "视频", "图片", "旅游", "公益", "农业"};

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return TITLES[position];
        }

        @Override
        public int getCount() {
            return TITLES.length;
        }

        @Override
        public Fragment getItem(int position) {
            return news[position];
        }

    }
}

package com.yonggang.ygcommunity.Entry;

/**
 * Created by liyangyang on 2017/3/8.
 */

public class News {
}

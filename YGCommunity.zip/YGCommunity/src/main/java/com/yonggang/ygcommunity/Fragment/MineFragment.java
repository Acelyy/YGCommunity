package com.yonggang.ygcommunity.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.yonggang.ygcommunity.Activity.LoginActivity;
import com.yonggang.ygcommunity.Activity.RegisterActivity;
import com.yonggang.ygcommunity.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by liyangyang on 2017/2/25.
 */

public class MineFragment extends Fragment {

    @BindView(R.id.line_message)
    LinearLayout lineMessage;
    @BindView(R.id.line_love)
    LinearLayout lineLove;
    @BindView(R.id.line_comment)
    LinearLayout lineComment;
    @BindView(R.id.line_option)
    LinearLayout lineOption;
    @BindView(R.id.line_setting)
    LinearLayout lineSetting;

    @BindView(R.id.head_mine_inLogin)
    RelativeLayout headMineInLogin;
    @BindView(R.id.head_mine_login)
    RelativeLayout headMineLogin;


    @BindView(R.id.mine_score)
    TextView mineScore;
    @BindView(R.id.mine_head)
    ImageView mineHead;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.layout_fragment_mine, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @OnClick({R.id.button_to_login, R.id.text_to_register, R.id.line_message, R.id.line_love, R.id.line_comment, R.id.line_option, R.id.line_setting})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_to_login:
                goActivity(LoginActivity.class);
                break;
            case R.id.text_to_register:
                goActivity(RegisterActivity.class);
                break;
            case R.id.line_message:
                break;
            case R.id.line_love:
                break;
            case R.id.line_comment:
                break;
            case R.id.line_option:
                break;
            case R.id.line_setting:
                break;
        }
    }

    private void goActivity(Class clz) {
        Intent intent = new Intent(getActivity(), clz);
        startActivity(intent);
    }
}
